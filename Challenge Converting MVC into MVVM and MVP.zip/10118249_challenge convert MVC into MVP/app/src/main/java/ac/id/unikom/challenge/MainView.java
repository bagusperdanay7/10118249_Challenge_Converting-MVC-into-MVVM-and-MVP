package ac.id.unikom.challenge;

public interface MainView {
    void showCentimeter(String centimeter);
    void showKilometer(String kilometer);
}
